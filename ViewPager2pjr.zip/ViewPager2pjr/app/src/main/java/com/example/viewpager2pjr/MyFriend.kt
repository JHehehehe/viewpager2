package com.example.viewpager2pjr

class MyFriend (
    val name: String,
    val phone: String,
    val email: String
)